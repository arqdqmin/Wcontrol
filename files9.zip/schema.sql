-- ============================================================
-- Esquema de base de datos para Control de Asistencia y
-- Liquidaciones - The Wizard Coffee SPA
-- Ejecutar completo en Supabase: Project > SQL Editor > New query
-- ============================================================

-- Extensión necesaria para generar UUIDs
create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- Tabla: empresa (una sola fila con los datos de la empresa)
-- ------------------------------------------------------------
create table if not exists empresa (
  id int primary key default 1,
  rut text default '',
  nombre text default '',
  direccion text default '',
  logo_path text,
  logo_url text,
  updated_at timestamptz default now(),
  constraint empresa_single_row check (id = 1)
);

insert into empresa (id, rut, nombre, direccion)
values (1, '77.555.667-6', 'THE WIZARD COFFEE SPA', 'HOMERO ÁVILA 850')
on conflict (id) do nothing;

-- ------------------------------------------------------------
-- Tabla: trabajadores
-- ------------------------------------------------------------
create table if not exists trabajadores (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  rut text default '',
  cargo text default '',
  centro_negocio text default '',
  tipo_contrato text default 'PLAZO FIJO',
  fecha_inicio date,
  fecha_fin date,
  indefinido boolean default false,
  domicilio text default '',
  telefono text default '',
  correo text default '',
  banco text default '',
  tipo_cuenta text default '',
  numero_cuenta text default '',
  contrato_path text,
  contrato_nombre text,
  sueldo_base numeric default 0,
  afp text default '',
  tasa_afp numeric default 10.46,
  afp_adicional numeric default 0,
  institucion_salud text default 'FONASA',
  plan_salud numeric default 7,
  dias_laborales text default 'lunes-viernes',
  hrs_semana numeric default 44,
  horario_semana jsonb default '{}'::jsonb,
  activo boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ------------------------------------------------------------
-- Tabla: asistencia_mensual (un registro por trabajador/mes/año)
-- ------------------------------------------------------------
create table if not exists asistencia_mensual (
  id uuid primary key default gen_random_uuid(),
  trabajador_id uuid not null references trabajadores(id) on delete cascade,
  anio int not null,
  mes int not null, -- 0 = enero ... 11 = diciembre
  dias_data jsonb not null default '[]'::jsonb,
  resumen jsonb not null default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (trabajador_id, anio, mes)
);

-- ------------------------------------------------------------
-- Tabla: liquidaciones (un registro por trabajador/mes/año)
-- ------------------------------------------------------------
create table if not exists liquidaciones (
  id uuid primary key default gen_random_uuid(),
  trabajador_id uuid not null references trabajadores(id) on delete cascade,
  anio int not null,
  mes int not null,
  datos jsonb not null default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (trabajador_id, anio, mes)
);

-- ------------------------------------------------------------
-- Seguridad: Row Level Security
-- Solo usuarios autenticados (con sesión iniciada) pueden
-- leer/escribir. El público (anon sin sesión) no puede acceder.
-- ------------------------------------------------------------
alter table empresa enable row level security;
alter table trabajadores enable row level security;
alter table asistencia_mensual enable row level security;
alter table liquidaciones enable row level security;

drop policy if exists "auth_all_empresa" on empresa;
create policy "auth_all_empresa" on empresa
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

drop policy if exists "auth_all_trabajadores" on trabajadores;
create policy "auth_all_trabajadores" on trabajadores
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

drop policy if exists "auth_all_asistencia" on asistencia_mensual;
create policy "auth_all_asistencia" on asistencia_mensual
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

drop policy if exists "auth_all_liquidaciones" on liquidaciones;
create policy "auth_all_liquidaciones" on liquidaciones
  for all using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- ------------------------------------------------------------
-- MIGRACIÓN: columnas agregadas en versiones posteriores.
-- Seguro de volver a correr esto en una base de datos que ya existe
-- (no borra ni modifica nada de lo que ya tengas guardado).
-- ------------------------------------------------------------
alter table empresa add column if not exists logo_path text;
alter table empresa add column if not exists logo_url text;

alter table trabajadores add column if not exists indefinido boolean default false;
alter table trabajadores add column if not exists domicilio text default '';
alter table trabajadores add column if not exists telefono text default '';
alter table trabajadores add column if not exists correo text default '';
alter table trabajadores add column if not exists banco text default '';
alter table trabajadores add column if not exists tipo_cuenta text default '';
alter table trabajadores add column if not exists numero_cuenta text default '';
alter table trabajadores add column if not exists contrato_path text;
alter table trabajadores add column if not exists contrato_nombre text;

-- ------------------------------------------------------------
-- MIGRACIÓN: buckets de almacenamiento (logo de empresa y contratos).
-- "logos" es público (para que el logo se vea en la liquidación impresa
-- sin pedir sesión), "contratos" es privado (solo accesible autenticado).
-- ------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('logos', 'logos', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('contratos', 'contratos', false)
on conflict (id) do nothing;

drop policy if exists "contratos_auth_all" on storage.objects;
create policy "contratos_auth_all" on storage.objects
  for all using (bucket_id = 'contratos' and auth.role() = 'authenticated')
  with check (bucket_id = 'contratos' and auth.role() = 'authenticated');

drop policy if exists "logos_read_public" on storage.objects;
create policy "logos_read_public" on storage.objects
  for select using (bucket_id = 'logos');

drop policy if exists "logos_write_auth" on storage.objects;
create policy "logos_write_auth" on storage.objects
  for insert with check (bucket_id = 'logos' and auth.role() = 'authenticated');

drop policy if exists "logos_update_auth" on storage.objects;
create policy "logos_update_auth" on storage.objects
  for update using (bucket_id = 'logos' and auth.role() = 'authenticated');

drop policy if exists "logos_delete_auth" on storage.objects;
create policy "logos_delete_auth" on storage.objects
  for delete using (bucket_id = 'logos' and auth.role() = 'authenticated');
